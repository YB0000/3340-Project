package com.yu.shoppingmall.shoppingmall;

import com.yu.shoppingmall.mapper.JgMapper;
import com.yu.shoppingmall.mapper.UserMapper;
import com.yu.shoppingmall.pojo.Jg;
import com.yu.shoppingmall.pojo.User;
import com.yu.shoppingmall.service.UserService;
import com.yu.shoppingmall.utli.DataBaseTableID;
import com.yu.shoppingmall.utli.GenNumTools;
import com.yu.shoppingmall.utli.ResultDao;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingMallApplicationTests {

    @Autowired
    JgMapper jgMapper;



    @Test
    void contextLoads() {
        /*String maxId = userMapper.getMaxId();
        String id = GenNumTools.initId(DataBaseTableID.UserComment, 4, maxId);
        System.out.println(id);*/

        Jg jg = jgMapper.selectById(1);
        System.out.println(jg);
    }

}
