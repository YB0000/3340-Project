package com.yu.shoppingmall.controller;

import com.yu.shoppingmall.service.OrderMxViewService;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class OrderMxController {

    @Autowired
    OrderMxViewService orderMxViewService;

    @GetMapping("userQueryOrder/{uid}/{currPage}/{pageSize}")
    public ResultDao userQueryOrder(@PathVariable String uid,@PathVariable int currPage,@PathVariable int pageSize){
        return orderMxViewService.userQuery(uid, currPage, pageSize);
    }

    @GetMapping("adminQueryOrder/{currPage}/{pageSize}")
    public ResultDao adminQueryOrder(@PathVariable int currPage,@PathVariable int pageSize){
        return orderMxViewService.adminQuery(currPage, pageSize);
    }
}
