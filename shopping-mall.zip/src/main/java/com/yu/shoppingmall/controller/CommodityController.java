package com.yu.shoppingmall.controller;

import com.yu.shoppingmall.pojo.Commodity;
import com.yu.shoppingmall.service.CommodityService;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin
public class CommodityController {

    @Autowired
    CommodityService commodityService;

    @PostMapping("commodity")
    public ResultDao addCommodity(@RequestBody Commodity commodity){

       return commodityService.addCommodity(commodity);
    }

    @PostMapping("updateCommodity")
    public ResultDao updateCommodity(@RequestBody Commodity commodity){
        return commodityService.updateCommodity(commodity);
    }

    @DeleteMapping("commodity/{coid}")
    public ResultDao deletedCommodity(@PathVariable String coid){
        return commodityService.deletedCommodity(coid);
    }

    @GetMapping("commodity/{coid}")
    public ResultDao getCommodityById(@PathVariable String coid){
        return commodityService.queryCommodityByID(coid);
    }

    @GetMapping("commodity/{currPage}/{pageSize}")
    public ResultDao getCommodityByPage(@PathVariable int currPage,@PathVariable int pageSize){
        return commodityService.queryCommodityByPage(currPage, pageSize);
    }

    @GetMapping("IndexQueryCommodityByPage/{currPage}/{pageSize}")
    public ResultDao IndexQueryCommodityByPage(@PathVariable int currPage,@PathVariable int pageSize){
        return commodityService.IndexQueryCommodityByPage(currPage, pageSize);
    }

    @PostMapping("imgUpload")
    public ResultDao imgUpload(MultipartFile file){
        return commodityService.upLoadImg(file);
    }

    @GetMapping("search/{title}")
    public ResultDao search(@PathVariable String title){
        return commodityService.search(title,1,20);
    }
    @GetMapping("searchPage/{title}/{currPage}/{pageSize}")
    public ResultDao searchPage(@PathVariable String title,@PathVariable int currPage,@PathVariable int pageSize){
        return commodityService.search(title,currPage ,pageSize);
    }

    @GetMapping("/monitor")
    public Map clearHistory(){
        HashMap<Object, Object> maps = new HashMap<>();
        maps.put("code",200);
        maps.put("backstage",1);
        maps.put("database",1);
        return maps;
    }

}
