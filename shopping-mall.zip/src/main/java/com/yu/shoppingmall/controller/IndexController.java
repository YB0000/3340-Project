package com.yu.shoppingmall.controller;

import com.yu.shoppingmall.pojo.Record;
import com.yu.shoppingmall.service.RecordService;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@CrossOrigin
public class IndexController {
    @Autowired
    RecordService recordService;

  @PostMapping("/addRecord")
    public ResultDao addRecord(@RequestBody Record record){
      return recordService.addRecord(record);
  }

  @GetMapping("/getHistory/{uid}")
  public ResultDao getHistory(@PathVariable String uid){
      return recordService.queryRecord(uid);
  }
  @GetMapping("/clearHistory/{uid}")
  public ResultDao clearHistory(@PathVariable String uid){
      return recordService.clearHistory(uid);
  }


}
