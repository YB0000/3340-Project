package com.yu.shoppingmall.controller;

import com.yu.shoppingmall.pojo.ShoppingCart;
import com.yu.shoppingmall.service.ShoppingCartMxViewService;
import com.yu.shoppingmall.service.ShoppingCartService;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
public class ShoppingCartController {

    @Autowired
    ShoppingCartService shoppingCartService;
    @Autowired
    ShoppingCartMxViewService shoppingCartMxViewService;

    @PostMapping("shoppingCart")
    public ResultDao addShoppingCart(@RequestBody ShoppingCart shoppingCart){
        return shoppingCartService.addShoppingCart(shoppingCart);
    }

    @DeleteMapping("delShoppingCartById/{id}")
    public ResultDao deletedShoppingCartByID(@PathVariable String id){
        return shoppingCartService.deletedById(id);
    }

    @DeleteMapping("delAllShoppingCart/{uid}")
    public ResultDao deletedAllShoppingCart(@PathVariable String uid){
        return shoppingCartService.deletedAll(uid);
    }


    @GetMapping("queryShoppingCart/{uid}/{currPage}/{pageSize}")
    public ResultDao queryShoppingCart(@PathVariable String uid,
                                       @PathVariable int currPage,
                                       @PathVariable int pageSize){
        return shoppingCartMxViewService.userQuery(uid,currPage, pageSize);
    }

}
