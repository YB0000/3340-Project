package com.yu.shoppingmall.controller;


import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@RestController
@CrossOrigin
public class ImgUrlController {
    @GetMapping("getTqUrl/{title}")
    public Map<String,Object> getTqUrl(@PathVariable String title){
        HashMap<String, Object> maps = new HashMap<>();
        HashMap<String, Object> tqMaps = new HashMap<>();
        tqMaps.put("晴","http://localhost:8080/images/qing.png");
        tqMaps.put("云","http://localhost:8080/images/douyun.png");
        tqMaps.put("雪","http://localhost:8080/images/xue.png");
        tqMaps.put("阴","http://localhost:8080/images/yin.png");
        tqMaps.put("雨","http://localhost:8080/images/yu.png");
        tqMaps.put("风","http://localhost:8080/images/feng.png");
        Set<String> keySet = tqMaps.keySet();
        String tqUrl = "";
       for(String key : keySet){
           if (title.contains(key)) {
               tqUrl = tqMaps.get(key).toString();
           }
       }

       if(tqUrl.equals("")){
           maps.put("imgUrl","http://localhost:8080/images/unknown.png");
       }else {
           maps.put("imgUrl",tqUrl);
       }

        return maps;
    }
}
