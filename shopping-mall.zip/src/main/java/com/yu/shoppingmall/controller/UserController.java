package com.yu.shoppingmall.controller;

import com.yu.shoppingmall.pojo.User;
import com.yu.shoppingmall.service.UserService;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping("user")
    public ResultDao addUser(@RequestBody User user){
        return userService.addUser(user);
    }

    @PostMapping("updateUser")
    public ResultDao updateUser(@RequestBody User user){
        return userService.updateUser(user);
    }

    @GetMapping("user/{uid}")
    public ResultDao getUserByID(@PathVariable String uid){
        return userService.queryUserByID(uid);
    }

    @GetMapping("user/{currPage}/{pageSize}")
    public ResultDao getUserByPage(@PathVariable int currPage,@PathVariable int pageSize){
        return userService.queryUserByPage(currPage, pageSize);
    }

    @DeleteMapping ("user/{uid}")
    public ResultDao deletedUser(@PathVariable String uid){
        return userService.deletedUser(uid);
    }



}
