package com.yu.shoppingmall.controller;

import com.yu.shoppingmall.pojo.vo.LoginView;
import com.yu.shoppingmall.service.UserService;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin
public class LogInController {

    @Autowired
    UserService userService;

    @PostMapping("login")
    public ResultDao logIn(@RequestBody LoginView loginView){
        return userService.Login(loginView);
    }
}
