package com.yu.shoppingmall.controller;

import com.yu.shoppingmall.pojo.ProductOrder;
import com.yu.shoppingmall.service.ProductOrderService;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@CrossOrigin
public class ProductOrderController {

    @Autowired
    ProductOrderService productOrderService;

    @PostMapping("order")
    public ResultDao addOrder(@RequestBody ProductOrder productOrder){
        return productOrderService.addOrder(productOrder);
    }
    @GetMapping("order/{orderId}")
    public ResultDao queryOrder(@PathVariable String orderId){
        return productOrderService.queryOrder(orderId);
    }
    @PutMapping("order/{orderId}/{code}")
    public ResultDao updateOderCode(@PathVariable String orderId,@PathVariable int code){
        return productOrderService.updateOderCode(orderId, code);
    }
    @GetMapping("order/{currPage}/{pageSize}")
    public ResultDao queryOrderByPage(@PathVariable int currPage, @PathVariable int pageSize){
        return productOrderService.queryOrderByPage(currPage, pageSize);
    }

}
