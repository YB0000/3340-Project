package com.yu.shoppingmall.controller;

import com.yu.shoppingmall.pojo.Reply;
import com.yu.shoppingmall.pojo.UserComment;
import com.yu.shoppingmall.service.UserCommentService;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
public class UserCommentController {
    @Autowired
    UserCommentService userCommentService;

    @PostMapping("addUserComment")
    public ResultDao addUserComment(@RequestBody UserComment userComment){
        return userCommentService.addUserComment(userComment);
    }

    @GetMapping("/queryMessage/{coid}/{currPage}/{pageSize}")
    public ResultDao queryMessage(@PathVariable String coid,
                                  @PathVariable int currPage,
                                  @PathVariable int pageSize){
        return userCommentService.queryMessage(coid, currPage, pageSize);
    }


}
