package com.yu.shoppingmall.pojo;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Reply { //reply table
    @TableId
    private String reid;
    private String cmid; // comment id
    @TableField(fill = FieldFill.INSERT)
    private String reDate; // reply time
    private String reContent; // reply content
}
