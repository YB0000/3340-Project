package com.yu.shoppingmall.pojo.view;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ShoppingCartMxView {
    private String uid;
    private String coid;
    private String scid;
    private String coname;
    private String title;
    private Double price;
    private Integer scnumber;
    private Date scdate;

}
