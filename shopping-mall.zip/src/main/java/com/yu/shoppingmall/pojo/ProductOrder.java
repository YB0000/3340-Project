package com.yu.shoppingmall.pojo;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProductOrder {//Order table entity class
    @TableId
    private String orderId;
    private String uid;
    private String coid; //product id
    private Integer orderNumber; //quantity of order
    @TableField(fill = FieldFill.INSERT)
    private Date orderDate;  // order date
    private Integer orderCode; // order status

}
