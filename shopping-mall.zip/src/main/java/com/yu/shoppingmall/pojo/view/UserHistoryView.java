package com.yu.shoppingmall.pojo.view;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserHistoryView {
    private String recordid;
    private String uid;
    private String coname;
    private Double price;
    private String imgUrl;
    private String title;
    private Date recorddate;
}
