package com.yu.shoppingmall.pojo;


import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Commodity { // commodity entity
    @TableId
    private String coid; //product id
    private String coname;//product name
    private Double price; //product price
    private String title; //product title
    private String jhtitle; //product jhtitle
    private String productDescription; // product description
    private String imgUrl; //product image url
    private Integer conumber; //product number
    private Integer code; // Status: 0 on stock, 1 off stock
}
