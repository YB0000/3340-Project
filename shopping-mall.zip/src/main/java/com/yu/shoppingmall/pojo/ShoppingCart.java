package com.yu.shoppingmall.pojo;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShoppingCart { //shopping cart entity class
    @TableId
    private String scid;  // shopping cart id
    private String coid;// product id
    private String uid;// user id
    @TableField(fill = FieldFill.INSERT)
    private Date scdate;// time to add into cart
    private Integer scNumber; //quantity that added into cart
}
