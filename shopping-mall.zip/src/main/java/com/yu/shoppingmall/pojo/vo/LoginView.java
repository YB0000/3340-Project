package com.yu.shoppingmall.pojo.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//登录 参数封装
@Data
@AllArgsConstructor
@NoArgsConstructor
public class  LoginView {
private String user;
private String pwd;
}
