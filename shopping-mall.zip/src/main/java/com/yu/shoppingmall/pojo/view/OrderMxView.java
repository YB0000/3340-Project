package com.yu.shoppingmall.pojo.view;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;



@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderMxView {
    private String orderid;
    private String uid;
    private String coid;
    private String uname;
    private String coname;
    private Double price;
    private String imgUrl;
    private Integer ordernumber;
    private Date orderdate;
    private Integer ordercode;
}
