package com.yu.shoppingmall.pojo;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Record { //History table
    @TableId
    private String recordId;
    private String uid;
    private String coid; //product id
    @TableField(fill = FieldFill.INSERT)
    private Date recorddate; //view time

}
