package com.yu.shoppingmall.pojo.view;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserMessageView {

    @TableId
    private String cmid; // comment id
    private String uname; // user id
    private String coid; // product on sell id
    @TableField(fill = FieldFill.INSERT)
    private Date cmdate;  //Comment time
    private String cmcontent; // comments content

}
