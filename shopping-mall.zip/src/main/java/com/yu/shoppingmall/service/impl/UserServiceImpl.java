package com.yu.shoppingmall.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yu.shoppingmall.mapper.UserMapper;
import com.yu.shoppingmall.pojo.vo.LoginView;
import com.yu.shoppingmall.pojo.User;
import com.yu.shoppingmall.service.UserService;
import com.yu.shoppingmall.utli.DataBaseTableID;
import com.yu.shoppingmall.utli.GenNumTools;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserMapper userMapper;

    @Override
    public ResultDao addUser(User user) {
        ResultDao resultDao = new ResultDao();
        if(isUser(user.getUser())){
            user.setUid(GenNumTools.initId(DataBaseTableID.User,4,userMapper.getMaxId()));
            user.setUtype(0);
            int insert = userMapper.insert(user);

            if(insert == 1){
                resultDao.setCode(201);
                resultDao.setMessage("account created");
            }else{
                resultDao.setCode(400);
                resultDao.setMessage("account created failed");
            }
        }else {
            resultDao.setCode(400);
            resultDao.setMessage("account already exists");
        }

        return resultDao;
    }

    @Override
    public ResultDao updateUser(User user) {
        int update = userMapper.updateById(user);
        ResultDao resultDao = new ResultDao();
        if(update == 1){
            resultDao.setCode(200);
            resultDao.setMessage("modify success");
        }else{
            resultDao.setCode(400);
            resultDao.setMessage("modify failed");
        }
        return resultDao;
    }

    @Override
    public ResultDao deletedUser(String Uid) {
        int delete = userMapper.deleteById(Uid);
        ResultDao resultDao = new ResultDao();
        if(delete == 1){
            resultDao.setCode(200);
            resultDao.setMessage("delete success");
        }else{
            resultDao.setCode(400);
            resultDao.setMessage("delete failed");
        }
        return resultDao;
    }

    @Override
    public ResultDao queryUserByID(String Uid) {
        User user = userMapper.selectById(Uid);
        ResultDao resultDao = new ResultDao();
        if(Uid != null){
            resultDao.setCode(201);
            resultDao.setMessage("check success");
            resultDao.setObj(user);
        }else{
            resultDao.setCode(400);
            resultDao.setMessage("check failed");
        }
        return resultDao;
    }

    @Override
    public ResultDao queryUserByPage(int currPage, int pageSize) {
        Page<User> userPage = new Page<>(currPage, pageSize);
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.ne("utype",1);
        ResultDao resultDao = new ResultDao();
        userMapper.selectPage(userPage, wrapper);
        resultDao.setData(userPage.getRecords());
        resultDao.setCode(200);
        resultDao.setMessage("check success");
        resultDao.setTotal(userPage.getTotal());
        return resultDao;
    }

    @Override
    public ResultDao Login(LoginView loginView) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("user",loginView.getUser()).eq("pwd",loginView.getPwd());
        User user = userMapper.selectOne(wrapper);
        ResultDao resultDao = new ResultDao();
        if(user == null){
            resultDao.setCode(400);
            resultDao.setMessage("account or password error");
        }else{
            if(user.getUtype() == 2){
                resultDao.setCode(400);
                resultDao.setMessage("The account has been frozen");
            }else{
                resultDao.setCode(200);
                resultDao.setMessage("login success");
                resultDao.setObj(user);
            }

        }
        return resultDao;
    }

    /**
     * Determine if a user account exists
     * @param user user account
     * @return
     */

    private boolean isUser(String user){
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("user",user);
        User isUser = userMapper.selectOne(wrapper);

        return isUser == null? true : false;
    }
}
