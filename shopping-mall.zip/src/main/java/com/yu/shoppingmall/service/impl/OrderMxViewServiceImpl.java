package com.yu.shoppingmall.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yu.shoppingmall.mapper.JgMapper;
import com.yu.shoppingmall.mapper.OrderMxViewMapper;
import com.yu.shoppingmall.pojo.view.OrderMxView;
import com.yu.shoppingmall.service.OrderMxViewService;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderMxViewServiceImpl implements OrderMxViewService {
    @Autowired
    OrderMxViewMapper orderMxViewMapper;
    @Override
    public ResultDao userQuery(String uid, int currPage, int pageSize) {
        Page<OrderMxView> page = new Page<>(currPage, pageSize);
        QueryWrapper<OrderMxView> wrapper = new QueryWrapper<>();
        wrapper.eq("uid",uid);
        orderMxViewMapper.selectPage(page, wrapper);
        ResultDao resultDao = new ResultDao();
        resultDao.setCode(200);
        resultDao.setTotal(page.getTotal());
        resultDao.setData(page.getRecords());
        return resultDao;
    }


    @Autowired
    JgMapper jgMapper;

    @Override
    public ResultDao adminQuery(int currPage, int pageSize) {
        Page<OrderMxView> page = new Page<>(currPage, pageSize);
        orderMxViewMapper.selectPage(page, null);

        ResultDao resultDao = new ResultDao();
        resultDao.setCode(200);
        resultDao.setTotal(page.getTotal());
        resultDao.setData(page.getRecords());
        resultDao.setObj(jgMapper.selectById(1).getPrice());
        return resultDao;
    }
}
