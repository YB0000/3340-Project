package com.yu.shoppingmall.service;

import com.yu.shoppingmall.pojo.ProductOrder;
import com.yu.shoppingmall.utli.ResultDao;

public interface ProductOrderService {

    ResultDao addOrder(ProductOrder productOrder);
    ResultDao queryOrder(String uid); //Query all order information by user id
    ResultDao updateOderCode(String orderId,int code); // Modify order status
    ResultDao queryOrderByPage(int currPage,int pageSize); // Paging to get order data
}
