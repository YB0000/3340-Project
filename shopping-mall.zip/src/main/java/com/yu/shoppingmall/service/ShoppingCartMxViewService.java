package com.yu.shoppingmall.service;


import com.yu.shoppingmall.utli.ResultDao;

public interface ShoppingCartMxViewService {
    ResultDao userQuery(String uid, int currPage, int pageSize); // User query
}
