package com.yu.shoppingmall.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.yu.shoppingmall.mapper.RecordMapper;
import com.yu.shoppingmall.mapper.UserHistoryViewMapper;
import com.yu.shoppingmall.pojo.Record;
import com.yu.shoppingmall.pojo.view.UserHistoryView;
import com.yu.shoppingmall.service.RecordService;
import com.yu.shoppingmall.utli.DataBaseTableID;
import com.yu.shoppingmall.utli.GenNumTools;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecordServiceImpl implements RecordService {

    @Autowired
    RecordMapper recordMapper;
    @Override
    public ResultDao addRecord(Record record) {
        QueryWrapper<Record> wrapper = new QueryWrapper<>();
        wrapper.eq("uid",record.getUid()).eq("coid",record.getCoid());
        Record extend = recordMapper.selectOne(wrapper);
        ResultDao resultDao = new ResultDao();
        if(extend == null){
            record.setRecordId(GenNumTools.initId(DataBaseTableID.Record,4,recordMapper.getMaxId()));
            int insert = recordMapper.insert(record);
            if(insert == 1){
                resultDao.setCode(201);
            }else{
                resultDao.setCode(400);
            }
        }
        return resultDao;
    }

    @Autowired
    UserHistoryViewMapper userHistoryViewMapper;

    @Override
    public ResultDao queryRecord(String uid) {
        QueryWrapper<UserHistoryView> wrapper = new QueryWrapper<>();
        wrapper.eq("uid",uid);
        List<UserHistoryView> records = userHistoryViewMapper.selectList(wrapper);
        ResultDao resultDao = new ResultDao();
        resultDao.setCode(200);
        resultDao.setData(records);
        return resultDao;
    }

    @Override
    public ResultDao clearHistory(String uid) {
        QueryWrapper<Record> wrapper = new QueryWrapper<>();
        wrapper.eq("uid",uid);
        recordMapper.delete(wrapper);
        ResultDao resultDao = new ResultDao();
        resultDao.setCode(200);
        return resultDao;
    }
}
