package com.yu.shoppingmall.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yu.shoppingmall.mapper.CommodityMapper;
import com.yu.shoppingmall.mapper.JgMapper;
import com.yu.shoppingmall.mapper.OrderMxViewMapper;
import com.yu.shoppingmall.mapper.ProductOrderMapper;
import com.yu.shoppingmall.pojo.Commodity;
import com.yu.shoppingmall.pojo.Jg;
import com.yu.shoppingmall.pojo.ProductOrder;
import com.yu.shoppingmall.pojo.view.OrderMxView;
import com.yu.shoppingmall.service.ProductOrderService;
import com.yu.shoppingmall.utli.DataBaseTableID;
import com.yu.shoppingmall.utli.GenNumTools;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class ProductOrderServiceImpl implements ProductOrderService {
    @Autowired
    ProductOrderMapper productOrderMapper;
    @Override
    public ResultDao addOrder(ProductOrder productOrder) {
        productOrder.setOrderId(GenNumTools.initId(DataBaseTableID.ProductOrder,4,productOrderMapper.getMaxId()));
        int insert = productOrderMapper.insert(productOrder);
        ResultDao resultDao = new ResultDao();
        if(insert == 1){
            resultDao.setCode(201);
            resultDao.setMessage("order add success");
        }else {
            resultDao.setCode(400);
            resultDao.setMessage("order add fail");
        }
        return resultDao;
    }

    @Autowired
    OrderMxViewMapper orderMxViewMapper;

    @Override
    public ResultDao queryOrder(String uid) {
        QueryWrapper<OrderMxView> wrapper = new QueryWrapper<>();
        wrapper.eq("uid",uid);
        List<OrderMxView> orderMxViews = orderMxViewMapper.selectList(wrapper);
        ResultDao resultDao = new ResultDao();
        resultDao.setCode(200);
        resultDao.setMessage("check order success");
        resultDao.setData(orderMxViews);
        return resultDao;
    }

    @Autowired
    CommodityMapper commodityMapper;
    @Autowired
    JgMapper jgMapper;
    @Override
    public ResultDao updateOderCode(String orderId,int code) {
        ProductOrder productOrder = productOrderMapper.selectById(orderId);
        if(code == 2){
            Commodity commodity = commodityMapper.selectById(productOrder.getCoid());
            commodity.setConumber(commodity.getConumber() + 1);
            commodityMapper.updateById(commodity);
            Jg jg = jgMapper.selectById(1);
            jg.setPrice(jg.getPrice() + productOrder.getOrderNumber() * commodity.getPrice());
            jgMapper.updateById(jg);
        }

        productOrder.setOrderCode(code);
        int update = productOrderMapper.updateById(productOrder);
        ResultDao resultDao = new ResultDao();
        if(update == 1){
            resultDao.setCode(200);
            resultDao.setMessage("update order status success");
        }else{
            resultDao.setCode(200);
            resultDao.setMessage("update order status fail");
        }
        return resultDao;
    }

    @Override
    public ResultDao queryOrderByPage(int currPage, int pageSize) {
        Page<OrderMxView> page = new Page<>(currPage, pageSize);

        ResultDao resultDao = new ResultDao();
        orderMxViewMapper.selectPage(page, null);
        resultDao.setData(page.getRecords());
        resultDao.setCode(200);
        resultDao.setMessage("check success");
        resultDao.setTotal(page.getTotal());
        return resultDao;
    }
}
