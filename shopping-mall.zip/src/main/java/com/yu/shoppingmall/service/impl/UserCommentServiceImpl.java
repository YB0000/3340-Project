package com.yu.shoppingmall.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yu.shoppingmall.mapper.ReplyMapper;
import com.yu.shoppingmall.mapper.UserCommentMapper;
import com.yu.shoppingmall.mapper.UserMessageViewMapper;
import com.yu.shoppingmall.pojo.Reply;
import com.yu.shoppingmall.pojo.UserComment;
import com.yu.shoppingmall.pojo.view.UserMessageView;
import com.yu.shoppingmall.service.UserCommentService;
import com.yu.shoppingmall.utli.DataBaseTableID;
import com.yu.shoppingmall.utli.GenNumTools;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Service
public class UserCommentServiceImpl implements UserCommentService {

    @Autowired
    UserCommentMapper userCommentMapper;

    @Autowired
    ReplyMapper replyMapper;

    @Override
    public ResultDao addUserComment(UserComment userComment) {
        userComment.setCmid(GenNumTools.initId(DataBaseTableID.UserComment,4,userCommentMapper.getMaxId()));
        int insert = userCommentMapper.insert(userComment);
        ResultDao resultDao = new ResultDao();
        if(insert == 1){
            resultDao.setCode(201);
            resultDao.setMessage("comment success");
        }else{
            resultDao.setCode(400);
            resultDao.setMessage("comment fail");
        }
        return resultDao;
    }

    @Autowired
    UserMessageViewMapper userMessageViewMapper;

    @Override
    public ResultDao queryMessage(String coid, int currPage, int pageSize) {
        QueryWrapper<UserMessageView> wrapper = new QueryWrapper<>();
        wrapper.eq("coid",coid);
        Page<UserMessageView> page = new Page<>(currPage, pageSize);
        ResultDao resultDao = new ResultDao();
        userMessageViewMapper.selectPage(page, wrapper);
        resultDao.setData(page.getRecords());
        resultDao.setCode(200);
        resultDao.setMessage("check success");
        resultDao.setTotal(page.getTotal());
        return resultDao;
    }

}
