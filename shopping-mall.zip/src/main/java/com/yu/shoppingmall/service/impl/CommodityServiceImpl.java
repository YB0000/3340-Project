package com.yu.shoppingmall.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yu.shoppingmall.mapper.CommodityMapper;
import com.yu.shoppingmall.pojo.Commodity;
import com.yu.shoppingmall.service.CommodityService;
import com.yu.shoppingmall.utli.DataBaseTableID;
import com.yu.shoppingmall.utli.GenNumTools;
import com.yu.shoppingmall.utli.ResultDao;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

@Log4j2
@Service
public class CommodityServiceImpl implements CommodityService  {

    @Autowired
    CommodityMapper commodityMapper;

    @Override
    public ResultDao addCommodity(Commodity commodity) {
        commodity.setCoid(GenNumTools.initId(DataBaseTableID.Commodity,4,commodityMapper.getMaxId()));
        int insert = commodityMapper.insert(commodity);
        ResultDao resultDao = new ResultDao();
        if(insert == 1){
            resultDao.setCode(201);
            resultDao.setMessage("Add success");
        }else{
            resultDao.setCode(400);
            resultDao.setMessage("Add failed");
        }
        return resultDao;
    }

    @Override
    public ResultDao updateCommodity(Commodity commodity) {
        int update = commodityMapper.updateById(commodity);
        ResultDao resultDao = new ResultDao();
        if(update == 1){
            resultDao.setCode(200);
            resultDao.setMessage("Modify success");
        }else{
            resultDao.setCode(400);
            resultDao.setMessage("Modify failed");
        }
        return resultDao;
    }

    @Override
    public ResultDao deletedCommodity(String coid) {
        int delete = commodityMapper.deleteById(coid);
        ResultDao resultDao = new ResultDao();
        if(delete == 1){
            resultDao.setCode(201);
            resultDao.setMessage("Delete success");
        }else{
            resultDao.setCode(400);
            resultDao.setMessage("Delete failed");
        }
        return resultDao;
    }

    @Override
    public ResultDao queryCommodityByID(String coid) {
        ResultDao resultDao = new ResultDao();
        QueryWrapper<Commodity> wrapper = new QueryWrapper<>();
        wrapper.eq("coid",coid).eq("code",0);
        Commodity commodity = commodityMapper.selectOne(wrapper);
        if(commodity != null){
            resultDao.setCode(200);
            resultDao.setObj(commodity);
        }else {
            resultDao.setCode(400);
        }

        return resultDao;
    }


    @Override
    public ResultDao queryCommodityByPage(int currPage, int pageSize) {
        Page<Commodity> userPage = new Page<>(currPage, pageSize);

        ResultDao resultDao = new ResultDao();
        commodityMapper.selectPage(userPage, null);
        resultDao.setData(userPage.getRecords());
        resultDao.setCode(200);
        resultDao.setMessage("Check success");
        resultDao.setTotal(userPage.getTotal());
        return resultDao;
    }

    @Override
    public ResultDao IndexQueryCommodityByPage(int currPage, int pageSize) {
        Page<Commodity> userPage = new Page<>(currPage, pageSize);
        QueryWrapper<Commodity> wrapper = new QueryWrapper<>();
        wrapper.eq("code",0);
        ResultDao resultDao = new ResultDao();
        commodityMapper.selectPage(userPage, wrapper);
        resultDao.setData(userPage.getRecords());
        resultDao.setCode(200);
        resultDao.setMessage("Check success");
        resultDao.setTotal(userPage.getTotal());
        return resultDao;
    }

    @Override
    public ResultDao upLoadImg(MultipartFile file) {

        String filename = file.getOriginalFilename();
        String endStr = filename.substring(filename.length() - 4);
        String uuid = UUID.randomUUID().toString().substring(1, 8);
        String imgName = uuid + endStr;
        String savePath = "C:\\images";
        File newFile = new File(savePath);
        if(!newFile.exists()){
            newFile.mkdir();
        }

        try {
            file.transferTo(new File(newFile, imgName));
        }catch (IOException e){
            log.error("img upload failed");
        }
        String imgUrl = "http://localhost:8080/images/"+imgName;

        ResultDao resultDao = new ResultDao();
        resultDao.setCode(200);
        resultDao.setMessage("upload success");
        resultDao.setImgUrl(imgUrl);

        return resultDao;
    }

    @Override
    public ResultDao search(String title, int currPage,int pageSize) {
        QueryWrapper<Commodity> wrapper = new QueryWrapper<>();
        Page<Commodity> page = new Page<>(currPage, pageSize);
        wrapper.eq("code",0).like("coname", title);
        commodityMapper.selectPage(page, wrapper);
        ResultDao resultDao = new ResultDao();

        resultDao.setCode(200);
        resultDao.setData(page.getRecords());
        resultDao.setTotal(page.getTotal());
        return resultDao;
    }

}
