package com.yu.shoppingmall.service;

import com.yu.shoppingmall.pojo.vo.LoginView;
import com.yu.shoppingmall.pojo.User;
import com.yu.shoppingmall.utli.ResultDao;

public interface UserService {
    ResultDao addUser(User user);
    ResultDao updateUser(User user);
    ResultDao deletedUser(String Uid);
    ResultDao queryUserByID(String Uid);
    ResultDao queryUserByPage(int currPage,int pageSize);
    ResultDao Login(LoginView loginView);

}
