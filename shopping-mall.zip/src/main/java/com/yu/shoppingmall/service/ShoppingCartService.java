package com.yu.shoppingmall.service;

import com.yu.shoppingmall.pojo.ShoppingCart;
import com.yu.shoppingmall.utli.ResultDao;

public interface ShoppingCartService { // Shopping cart business interface

    ResultDao addShoppingCart(ShoppingCart shoppingCart);
    ResultDao deletedById(String scid); // Delete cart record by cart id
    ResultDao deletedAll(String uid); // empty cart
}
