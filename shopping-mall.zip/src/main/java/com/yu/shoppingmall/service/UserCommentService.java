package com.yu.shoppingmall.service;

import com.yu.shoppingmall.pojo.Reply;
import com.yu.shoppingmall.pojo.UserComment;
import com.yu.shoppingmall.utli.ResultDao;

public interface UserCommentService { // User comment business interface
    ResultDao addUserComment(UserComment userComment); // user comment
    ResultDao queryMessage(String coid,int currPage, int pageSize);



}
