package com.yu.shoppingmall.service;

import com.yu.shoppingmall.utli.ResultDao;

public interface OrderMxViewService {
    ResultDao userQuery(String uid,int currPage, int pageSize); // User query
    ResultDao adminQuery(int currPage, int pageSize);// Admin query

}
