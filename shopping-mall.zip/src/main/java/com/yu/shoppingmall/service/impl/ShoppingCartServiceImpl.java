package com.yu.shoppingmall.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.yu.shoppingmall.mapper.ShoppingCartMapper;
import com.yu.shoppingmall.pojo.ShoppingCart;
import com.yu.shoppingmall.service.ShoppingCartService;
import com.yu.shoppingmall.utli.DataBaseTableID;
import com.yu.shoppingmall.utli.GenNumTools;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ShoppingCartServiceImpl implements ShoppingCartService {
    @Autowired
    ShoppingCartMapper shoppingCartMapper;
    @Override
    public ResultDao addShoppingCart(ShoppingCart shoppingCart) {
        shoppingCart.setScid(GenNumTools.initId(DataBaseTableID.ShoppingCart,4, shoppingCartMapper.getMaxId()));
        int insert = shoppingCartMapper.insert(shoppingCart);
        ResultDao resultDao = new ResultDao();
        if(insert == 1){
            resultDao.setCode(201);
            resultDao.setMessage("Added to cart");
        }else{
            resultDao.setCode(400);
            resultDao.setMessage("Added to cart failed");
        }
        return resultDao;
    }

    @Override
    public ResultDao deletedById(String scid) {
        int delete = shoppingCartMapper.deleteById(scid);
        ResultDao resultDao = new ResultDao();
        if(delete == 1){
            resultDao.setCode(200);
            resultDao.setMessage("delete success");
        }else{
            resultDao.setCode(400);
            resultDao.setMessage("delete failed");
        }
        return resultDao;
    }

    @Override
    public ResultDao deletedAll(String uid) {
        QueryWrapper<ShoppingCart> wrapper = new QueryWrapper<>();
        wrapper.eq("uid",uid);
        shoppingCartMapper.delete(wrapper);
        ResultDao resultDao = new ResultDao();
        resultDao.setCode(200);
        resultDao.setMessage("delete success");
        return resultDao;
    }
}
