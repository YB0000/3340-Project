package com.yu.shoppingmall.service;

import com.yu.shoppingmall.pojo.Commodity;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.web.multipart.MultipartFile;

public interface CommodityService {
    ResultDao addCommodity(Commodity Commodity);
    ResultDao updateCommodity(Commodity Commodity);
    ResultDao deletedCommodity(String coid);
    ResultDao queryCommodityByID(String coid);
    ResultDao queryCommodityByPage(int currPage,int pageSize);
    ResultDao IndexQueryCommodityByPage(int currPage,int pageSize);
    ResultDao upLoadImg(MultipartFile file);
    ResultDao search(String title,int currPage,int pageSize);
}
