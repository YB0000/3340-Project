package com.yu.shoppingmall.service;


import com.yu.shoppingmall.pojo.Record;
import com.yu.shoppingmall.utli.ResultDao;

public interface RecordService {
    ResultDao addRecord(Record record);
    ResultDao queryRecord(String uid);
    ResultDao clearHistory(String uid);

}
