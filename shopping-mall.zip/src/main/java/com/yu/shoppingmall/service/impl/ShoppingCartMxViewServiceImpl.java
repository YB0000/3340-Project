package com.yu.shoppingmall.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.yu.shoppingmall.mapper.ShoppingCartMxViewMapper;
import com.yu.shoppingmall.pojo.view.ShoppingCartMxView;
import com.yu.shoppingmall.service.ShoppingCartMxViewService;
import com.yu.shoppingmall.utli.ResultDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ShoppingCartMxViewServiceImpl implements ShoppingCartMxViewService {
    @Autowired
    ShoppingCartMxViewMapper shoppingCartMxViewMapper;
    @Override
    public ResultDao userQuery(String uid, int currPage, int pageSize) {
        Page<ShoppingCartMxView> page = new Page<>(currPage, pageSize);
        QueryWrapper<ShoppingCartMxView> wrapper = new QueryWrapper<>();
        wrapper.eq("uid",uid);
        shoppingCartMxViewMapper.selectPage(page, wrapper);
        ResultDao resultDao = new ResultDao();
        resultDao.setCode(200);
        resultDao.setTotal(page.getTotal());
        resultDao.setData(page.getRecords());
        return resultDao;
    }
}
