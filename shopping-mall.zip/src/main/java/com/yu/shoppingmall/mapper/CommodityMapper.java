package com.yu.shoppingmall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yu.shoppingmall.pojo.Commodity;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface CommodityMapper extends BaseMapper<Commodity> {
    @Select("select max(coid) from Commodity")
    String getMaxId();
}
