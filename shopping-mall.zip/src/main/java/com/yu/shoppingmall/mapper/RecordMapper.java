package com.yu.shoppingmall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yu.shoppingmall.pojo.Record;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface RecordMapper extends BaseMapper<Record> {
    @Select("select max(recordId) from Record")
    String getMaxId();
}
