package com.yu.shoppingmall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yu.shoppingmall.pojo.ShoppingCart;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface ShoppingCartMapper extends BaseMapper<ShoppingCart> {
    @Select("select max(scid) from Shopping_Cart")
    String getMaxId();
}
