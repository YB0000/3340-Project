package com.yu.shoppingmall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yu.shoppingmall.pojo.Jg;
import org.springframework.stereotype.Repository;

@Repository
public interface JgMapper extends BaseMapper<Jg> {
}
