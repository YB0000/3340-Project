package com.yu.shoppingmall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yu.shoppingmall.pojo.ProductOrder;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductOrderMapper extends BaseMapper<ProductOrder> {
    @Select("select max(orderId) from Product_Order")
    String getMaxId();
}
