package com.yu.shoppingmall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yu.shoppingmall.pojo.Reply;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface ReplyMapper extends BaseMapper<Reply> {
    @Select("select max(reid) from Reply")
    String getMaxId();
}
