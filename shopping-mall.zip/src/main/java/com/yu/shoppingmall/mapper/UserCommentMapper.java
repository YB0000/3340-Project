package com.yu.shoppingmall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yu.shoppingmall.pojo.UserComment;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface UserCommentMapper extends BaseMapper<UserComment> {
    @Select("select max(cmid) from User_Comment")
    String getMaxId();
}
