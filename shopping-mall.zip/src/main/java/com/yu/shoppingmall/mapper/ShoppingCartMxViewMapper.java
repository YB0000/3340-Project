package com.yu.shoppingmall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yu.shoppingmall.pojo.view.ShoppingCartMxView;
import org.springframework.stereotype.Repository;

@Repository
public interface ShoppingCartMxViewMapper  extends BaseMapper<ShoppingCartMxView> {
}
