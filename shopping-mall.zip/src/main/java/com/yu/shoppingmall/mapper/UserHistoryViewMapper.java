package com.yu.shoppingmall.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yu.shoppingmall.pojo.view.UserHistoryView;
import org.springframework.stereotype.Repository;

@Repository
public interface UserHistoryViewMapper extends BaseMapper<UserHistoryView> {
}
