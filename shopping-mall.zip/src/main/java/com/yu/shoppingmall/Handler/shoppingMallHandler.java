package com.yu.shoppingmall.Handler;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.util.Date;



@Component
@Slf4j
public class shoppingMallHandler implements MetaObjectHandler {

    @Override
    public void insertFill(MetaObject metaObject) {
        log.info("Automatically insert time parameters");
        //setFieldValByName(Database field name, create a time object, metaObject
        this.setFieldValByName("orderDate",new Date(),metaObject);
        this.setFieldValByName("scdate",new Date(),metaObject);
        this.setFieldValByName("reDate",new Date(),metaObject);
        this.setFieldValByName("cmdate",new Date(),metaObject);
        this.setFieldValByName("recorddate",new Date(),metaObject);
    }

    @Override
    public void updateFill(MetaObject metaObject) {

    }
}
