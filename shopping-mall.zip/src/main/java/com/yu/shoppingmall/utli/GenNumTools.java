package com.yu.shoppingmall.utli;

import cn.hutool.core.util.NumberUtil;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class GenNumTools {
    /**
     * Converting a character to an integer returns , unconverted output -1
     * @param str
     * @return
     */
    public static String initId(String beginHead,int size,String  str){

        if(str == null){
            str = beginHead;
            for (int i = 0; i < size; i++) {
                str += "0";
            }
        }
        int len = str.length();//get string length
        String processStr = str.substring(beginHead.length(),len);// Take the rest of the string after the header
        int result = -1;
        int zeroBeginIndex = 0;
        int processStrLen = processStr.length();//remaining string length
        String processResult = "error";
        if(NumberUtil.isNumber(processStr)) { //If the remaining string can be converted into numbers, it will start from the left and go to 0
            for (int i = 0; i < processStrLen; i++) {
                char chr = processStr.charAt(i);
                if (chr == '0') {
                    zeroBeginIndex++;
                } else {
                    break;
                }
            }
            String temp = processStr.substring(zeroBeginIndex,processStrLen);//Get the largest number according to the result of removing 0

            result = temp.equals("")?0:Integer.parseInt(temp);
            processResult =  beginHead+ addZero(size,result + 1);
        }
        return processResult;
    }
    public static <T> Consumer<T> consumerWithIndex(BiConsumer<T, Integer> consumer) {
        class Obj {
            int i;
        }
        Obj obj = new Obj();
        return t -> {
            int index = obj.i++;
            consumer.accept(t, index);
        };
    }


    /**
     * Integer zero-padded of specific string length
     * @param size
     * @param val
     * @return
     */
    public static String addZero(int size,int val){
        String result =  String.valueOf(val);
        int len = String.valueOf(val).length();
        if(size > len){
            String zeroStr = "";
            for(int i=0;i<size-len;i++){
                zeroStr += "0";
            }
            result  =zeroStr + result;
        }
        // System.out.println(result);
        return result;
    }

    public static void main(String[] args) {
        GenNumTools.initId("abc",10,"abc123456789");
    }
}
