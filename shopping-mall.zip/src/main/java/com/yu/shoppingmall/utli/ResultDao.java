package com.yu.shoppingmall.utli;

import lombok.Data;

import java.util.List;


@Data
public class ResultDao<v> {

    private int code;

    private String token;

    private String message;

    private List<v> data;

    private Object obj;

    private String url;

    private String imgUrl;

    private long total;
}
