package com.yu.shoppingmall.utli;


import com.sun.org.apache.bcel.internal.generic.NEW;
import lombok.extern.log4j.Log4j2;

import java.util.Properties;

@Log4j2
public class DataBaseTableID {
    public static String User;
    public static String Commodity;
    public static String ProductOrder;
    public static String Record;
    public static String Reply;
    public static String ShoppingCart;
    public static String UserComment;

    static {
        Properties prop = new Properties();// empty configuration class
        try{
            prop.load(DataBaseTableID.class.getResourceAsStream("/DatabaseTableIDbegin"));
        }catch (Exception e){
            log.error("Failed to load DatabaseTableIDbegin file");
        }
        User = prop.get("User").toString();
        Commodity = prop.get("Commodity").toString();
        ProductOrder = prop.get("ProductOrder").toString();
        Reply = prop.get("Reply").toString();
        Record = prop.get("Record").toString();
        ShoppingCart = prop.get("ShoppingCart").toString();
        UserComment = prop.get("UserComment").toString();

    }
}
